package com.example.crud;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    public SQLiteDatabase db;
    EditText userid;
    EditText username;
    ListView l1;
    ArrayAdapter mp;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try
        {
            db = openOrCreateDatabase("sample",SQLiteDatabase.CREATE_IF_NECESSARY,null);
            db.execSQL("Create Table demo(id integer,name text)");
        }
        catch (SQLException e)
        {

        }
        setContentView(R.layout.activity_main);
        userid = (EditText) findViewById(R.id.user_id);
        username = (EditText) findViewById(R.id.user_name);
    }

    public  void  Insert(View view){
        ContentValues value = new ContentValues();
        value.put("id",userid.getText().toString());
        value.put("name",username.getText().toString());

        if((db.insert("demo",null,value))!=-1)
        {
            Toast.makeText(this, "Record INSERT Sucessfully", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(this, "ERROR in INSERT data", Toast.LENGTH_SHORT).show();
        }
    }

    public void View(View view)
    {
        l1=(ListView) findViewById(R.id.lv);
        mp=new ArrayAdapter<>(MainActivity.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);

        Cursor c=db.rawQuery("SELECT * FROM demo",null);
        c.moveToFirst();
        while (!c.isAfterLast())
        {
            mp.add(c.getString(0)+c.getString(1));
            c.moveToNext();
        }
        c.close();
        l1.setAdapter(mp);
    }

    public void Update(View view)
    {
        String tname = username.getText().toString();
        String tid = userid.getText().toString();
        ContentValues cv = new ContentValues();
        cv.put("id",tid);
        cv.put("name",tname);
        db.update("demo",cv,"id=?",new String[]{tid});
        db.update("demo",cv,"name=?",new String[]{tname});

    }

    public  void Delete(View view)
    {
        String t_id = userid.getText().toString();
       db.execSQL("delete from demo where id="+t_id);

        //String wherecal="id=?";
        //String[] args={t_id};
        //db.delete("where");

    }
}

